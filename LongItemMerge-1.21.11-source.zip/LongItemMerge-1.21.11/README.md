# Long Item Merge — Minecraft 1.21.11 Fabric

Đây là **source project** để bạn tự build thành JAR.

## Chức năng
- Mỗi 20 tick, quét item entity trong phạm vi hình cầu 50 block quanh item đang xử lý.
- Chỉ gộp những stack mà Minecraft xác nhận tương thích (`ItemEntity.canMerge`).
- Không vượt giới hạn stack tối đa của item (thường là 64); số lượng dư vẫn nằm ở entity khác.
- Chỉ thay đổi dữ liệu ở server, nên dùng được trong singleplayer và server khi mod được cài phía server.

## Yêu cầu
- Minecraft Java 1.21.11
- Fabric Loader 0.18.1 trở lên
- Java 21
- Gradle 9.2 trở lên (Loom 1.14 yêu cầu Gradle 9.2)

## Build
Mở terminal tại thư mục project rồi chạy:

```bash
gradle build
```

JAR sau khi build nằm trong:

```text
build/libs/long-item-merge-1.0.0.jar
```

Chép JAR đó vào thư mục `mods`.

## Lưu ý quan trọng
Phạm vi 50 block khá rộng. Item cùng loại ở các nhánh nước, bộ lọc item hoặc khu vực farm khác nhau có thể bị gộp với nhau nếu chúng nằm trong phạm vi. Hãy thử trên bản sao thế giới trước; nếu farm dùng sorter/hopper, nên giảm bán kính trước khi dùng thật.

Mod này gộp entity thật ở server, không chỉ ẩn hình ảnh. Vì vậy số entity có thể giảm, nhưng không thể bảo đảm mọi farm sẽ giữ nguyên cách phân luồng item.
