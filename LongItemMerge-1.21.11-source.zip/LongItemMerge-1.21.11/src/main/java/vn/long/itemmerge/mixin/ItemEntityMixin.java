package vn.long.itemmerge.mixin;

import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(ItemEntity.class)
public abstract class ItemEntityMixin {
    private static final double LONG_MERGE_RADIUS = 50.0D;
    private static final double LONG_MERGE_RADIUS_SQUARED =
            LONG_MERGE_RADIUS * LONG_MERGE_RADIUS;
    private static final long SCAN_INTERVAL_TICKS = 20L;

    @Inject(method = "tick", at = @At("TAIL"))
    private void longItemMerge$mergeNearbyItems(CallbackInfo ci) {
        ItemEntity self = (ItemEntity) (Object) this;
        World world = self.getWorld();

        // Chỉ xử lý phía server; không chạy logic thay đổi item ở client.
        if (world.isClient || world.getTime() % SCAN_INTERVAL_TICKS != 0L) {
            return;
        }

        if (!self.isAlive() || self.getStack().isEmpty()) {
            return;
        }

        Box searchBox = self.getBoundingBox().expand(LONG_MERGE_RADIUS);
        List<ItemEntity> nearby = world.getEntitiesByClass(
                ItemEntity.class,
                searchBox,
                other -> other.isAlive()
                        && other != self
                        && other.getId() > self.getId()
                        && !other.getStack().isEmpty()
        );

        for (ItemEntity other : nearby) {
            if (!self.isAlive() || self.getStack().isEmpty()) {
                break;
            }

            if (self.squaredDistanceTo(other) > LONG_MERGE_RADIUS_SQUARED) {
                continue;
            }

            ItemStack targetStack = self.getStack().copy();
            ItemStack sourceStack = other.getStack().copy();

            // Chỉ gộp stack Minecraft xác nhận tương thích (cùng item/components).
            if (!ItemEntity.canMerge(targetStack, sourceStack)) {
                continue;
            }

            int freeSpace = targetStack.getMaxCount() - targetStack.getCount();
            int moved = Math.min(freeSpace, sourceStack.getCount());

            if (moved <= 0) {
                continue;
            }

            targetStack.increment(moved);
            sourceStack.decrement(moved);

            self.setStack(targetStack);

            if (sourceStack.isEmpty()) {
                other.discard();
            } else {
                other.setStack(sourceStack);
            }
        }
    }
}
