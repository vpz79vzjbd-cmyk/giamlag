package vn.long.itemmerge;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class LongItemMerge implements ModInitializer {
    public static final String MOD_ID = "long_item_merge";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Long Item Merge loaded. Merge radius: 50 blocks; scan interval: 20 ticks.");
    }
}
